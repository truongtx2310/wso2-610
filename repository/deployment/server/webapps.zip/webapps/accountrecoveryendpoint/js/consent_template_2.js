var customConsentTempalte2 =
    "<div class='consent-container-2 row'><div class='col-xs-6'><div class='box'>We would like to get" +
    " your approval to {{purpose:Educational Purposes}} with following information <ul><li>{{pii:Educational" +
    " Purposes:Full" +
    " Name}}</li>" +
    "<li>{{pii:Educational Purposes:Address}}</li></ul></div></div>" +
    "<div class='col-xs-6'><div class='box'>We need your approval to {{purpose:Test Purposes}}" +
    " with following information. " +
    "<ul><li>{{pii:Test Purposes:Department}}</li>" +
    "<li>{{pii:Test Purposes:Country}}</li><li>{{pii:Test Purposes:Last Name}}</li><li>{{pii:Test" +
    " Purposes:Gender}}</li></ul></div></div></div>";
